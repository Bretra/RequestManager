//
//  VHJsonTool.m
//  VHiPad
//
//  Created by vhall on 2018/4/23.
//  Copyright © 2018年 vhall. All rights reserved.
//

#import "VHJsonTool.h"

@implementation VHJsonTool

//字典转json
+ (NSString *)jsonStringFromDictionary:(NSDictionary *)dict {
    NSArray *keys = dict.allKeys;
    NSArray *values = dict.allValues;
    
    NSMutableString *result = [NSMutableString string];
    
    for (NSInteger i=0; i<keys.count; i++) {
        if( i == keys.count-1 ){
            if( [values[i] hasPrefix:@"{"] && [values[i] hasSuffix:@"}"] ){
                [result appendFormat:@"\"%@\":%@",keys[i],values[i]];
            }else{
                [result appendFormat:@"\"%@\":\"%@\"",keys[i],values[i]];
            }
        }else{
            if( [values[i] hasPrefix:@"{"] && [values[i] hasSuffix:@"}"] ){
                [result appendFormat:@"\"%@\":%@,",keys[i],values[i]];
            }else{
                [result appendFormat:@"\"%@\":\"%@\",",keys[i],values[i]];
            }
        }
    }
    result = [[[@"{" stringByAppendingString:result] stringByAppendingString:@"}"] copy];
    return result;
}

//json转字典
+ (NSDictionary *)jsonStringToDictionary:(NSString *)jsonString {
    if (!jsonString) {
        return nil;
    }
    NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSError *err;
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&err];
    if(err) {
        return nil;
    }
    return dic;
}


@end
