//
//  VHJsonTool.h
//  VHiPad
//
//  Created by vhall on 2018/4/23.
//  Copyright © 2018年 vhall. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface VHJsonTool : NSObject

//字典转json
+ (NSString *)jsonStringFromDictionary:(NSDictionary *)dict;

//json转字典
+ (NSDictionary *)jsonStringToDictionary:(NSString *)jsonString;

@end
