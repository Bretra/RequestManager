//
//  VHRequestManager.h
//  VHiPad
//
//  Created by vhall on 2018/4/23.
//  Copyright © 2018年 vhall. All rights reserved.
//

#import <Foundation/Foundation.h>

/// 网络超时时间
#define VHRequestManagerRequestTimeOut 30

/// 请求类型
typedef NS_ENUM(NSUInteger, VHHTTPMethod) {
    VHHTTPMethodGET,
    VHHTTPMethodPOST,
};

@interface VHRequestManager : NSObject

@property(class, nonatomic, readonly) VHRequestManager *sharedManager;

+ (instancetype)sharedManager;

// request
- (void)requestWithMethod:(VHHTTPMethod)method url:(NSString *)url params:(NSMutableDictionary *)params sucess:(void(^)(NSDictionary *))result failed:(void(^)(void))failure;

@end
