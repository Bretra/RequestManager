//
//  VHRequestManager.m
//  VHiPad
//
//  Created by vhall on 2018/4/23.
//  Copyright © 2018年 vhall. All rights reserved.
//

#import "VHRequestManager.h"
#import "VHJsonTool.h"
#import "Reachability.h"

@interface VHRequestManager ()

@property (nonatomic, strong) NSURLSession *sharedSession;

@property (nonatomic, strong) Reachability *reachability;

@end

@implementation VHRequestManager

+ (instancetype)sharedManager {
    static VHRequestManager *manager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[VHRequestManager alloc] init];
    });
    return manager;
}

- (instancetype)init {
    if (self = [super init]) {
        //初始化session
        self.sharedSession = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
        //添加网络状态通知
        self.reachability = [Reachability reachabilityForInternetConnection];
    }
    return self;
}
- (void)dealloc {

}

- (void)requestWithMethod:(VHHTTPMethod)method url:(NSString *)url params:(NSMutableDictionary *)params sucess:(void(^)(NSDictionary *))result failed:(void(^)(void))failure
{
    //当前无网络
    if ([self.reachability currentReachabilityStatus] == NotReachable) {
        failure();
        return;
    }
    //无url
    if (!url || url.length<=0) {
        failure();
        return;
    }
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    [request setHTTPMethod:(method == VHHTTPMethodGET) ? @"GET" : @"POST"];
    [request setTimeoutInterval:VHRequestManagerRequestTimeOut];
    [request setValue:@"application/x-www-form-urlencoded;charset=UTF-8" forHTTPHeaderField:@"Content-Type"];
    
    if (method == VHHTTPMethodPOST) {
        NSString *jsonString = [VHJsonTool jsonStringFromDictionary:params];
        NSData *data = [jsonString dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
        [request setHTTPBody:data];
    }
    
    NSURLSessionDataTask *task = [self.sharedSession dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {

        if (error || !data || !response || ((NSHTTPURLResponse *)response).statusCode != 200) {
            if (failure) {
                failure();
            }
            return;
        }
        
        NSString *jaonString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        NSDictionary *dict = [VHJsonTool jsonStringToDictionary:jaonString];

        dispatch_async(dispatch_get_main_queue(), ^{
            if (result) {
                result(dict);
            }
        });
    }];
    [task resume];
}

@end
